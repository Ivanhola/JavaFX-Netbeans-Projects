/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package card.memorize.game;

import card.memorize.game.Card.Card;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;

/**
 *
 * @author Ivans
 */
public class MainController implements Initializable {
    
    /*Method that executes upon opening this FXML file(window)*/
    @Override
    public void initialize(URL url, ResourceBundle rb) {
      start();
    }

    @FXML
    private AnchorPane mainPane;
    
    /*Variables (Global) that will be used in creating our program*/
            Card deck[];
            Card temparray[];
            Card gameBoard[];
            boolean clickable=true;
            int ctr=0;
            int correct=0;
            int clicked[]=new int[]{0,1};
    
   
    @FXML
    private void handleButtonAction(ActionEvent event) {
        
    }
    
    public void start(){
        /*Set our background*/
        setBackground();
        /*Set logic for our cards*/
        int numOfCards = 52;
        //initialize our deck array
        deck = new Card[numOfCards];
        /*Our gameboard will hold 36 cards*/
        gameBoard = new Card[36];
        temparray = new Card[36];
        
        
        //create an array of objects (cards)
        Card cards[] = new Card[numOfCards];
        //iterate through the length of our object array, and assign each object of the array into a new Card(i) object value
        for(int i = 0;i<cards.length;i++){
            cards[i] = new Card(i);
            
        }
        /*shuffle the cards by creating an index array*/
        int index[] = new int[numOfCards];
        /*fill the array with values 0-52*/
        for(int i = 0;i<index.length;i++){
            index[i] = i;
        }
        
        /*mix up the indexed array*/
       for(int i = 0;i<index.length;i++){
           //Create a random value from 1-52
           int temp = (int) (Math.random()*51);
          //System.out.println("temp value: " + temp);
          //create a variable named value, and set it equal to whatever the index is at
           int val = index[i];
           //set whatever index we're at equal to the index of the random number
           index[i] = index[temp];
           //set the random index equal to the value we were at originally
           index[temp] = val;
           //System.out.println(val);
       }//end of for loop
       
       /*put the cards in the deck*/
       for(int i = 0;i<52;i++){
          // System.out.println(index[i]);

           /*We set the deck, equal to the randomized cards, making the deck equal to random cards in order*/
           deck[i] = cards[index[i]];
           
           /*This will print out a set of random cards in our deck*/
           //System.out.println(deck[i].toString());
                      
       }//end of for loop
       
       /*Place the cards onto the gameboard 36 is the size of our gameboard(6x6)*/
       for(int i = 0;i<36;i++){
           if(i<18){
               gameBoard[i] = deck[index[i]];
              // System.out.println(gameBoard[i].toString());
           }else{
               gameBoard[i] = deck[index[i-18]];
               //System.out.println(gameBoard[i].toString());

           }
       } //end of for loop
       
       randomize();
    }
    
   
    /*this method will take our temparray variable, and mix up the card order from our gameBoard array*/
    public void randomize(){
        int random =  (int) (Math.random()*36);
        for(int i = 0;i<7;i++){
            for(int j = 0;j<36;j++){
               temparray[1] = gameBoard[random];
               temparray[2] = gameBoard[j];
               gameBoard[j] = temparray[1];
               gameBoard[random] = temparray[2];
               
            }
        }
        
    }
    
    /*TODO LEFT OFF HERE*/
    /*This method will reveal the image on our board*/
    public void revealImage(int current){
        if(clickable){
            clickable = false;
            
        }
        
    }
    
    
    
     /*method that Sets the background for our MainPane*/
    public void setBackground(){
    Image background = new Image("Cards/table.jpg", 192, 80, false, true);
    BackgroundImage backgroundImg = new BackgroundImage(background, BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT,BackgroundPosition.DEFAULT, null);
    mainPane.setBackground(new Background(backgroundImg));
    }
    
    
    
    
    
    
    
    
    
      //method that will test the cards and create a list of cards
    public void test(){
         int nCards = 52;
         Card deck[] = new Card[nCards];
        //for loop that iterates the size of nCards(52)
           for(int i = 0; i<nCards;i++){
               //create a new Card object, and set it equal to (i) print out the current card.
               deck[i] = new Card(i);
               System.out.print(deck[i].toString());
            }
    }

}
